=== ATA Radio ===
Requires at least: 5.8
Tested up to: 7.2
Requires PHP: 7.4
Stable tag: 3.0.0
License: GPLv2 or later

A listen-live radio player for the ministry website. Connects to the ATA Radio backend.

== Description ==

Add the player to any page with the shortcode:

    [dominion_radio]

The player shows what is on air, a seekable progress bar, mute, and the next track. Every listener is kept in sync with the station.

Optional shortcode attributes: backend, name, tagline, offline_message, heading (h1, h2 or h3; default h2), fit (yes or no; default yes), bg (https image address for the full-screen backdrop; "none" hides it), logo (https image address for the badge above the heading; "none" hides it), bg_size (small, medium, large or fill; default medium), bg_position (center 22%, center center, center top, center bottom, left center or right center).

The backdrop photo and logo default to the ministry's Golden Tribute montage and ATA logo. Change them under Settings > ATA Radio (Background image, Photo focus, Logo) or per page with the attributes above.

By default the player fills the screen below your site header and the page does not scroll. Use [dominion_radio fit="no"] to place it as an ordinary block inside a longer page.

== Installation ==

1. Plugins > Add New > Upload Plugin, choose dominion-radio.zip, Install, Activate.
2. Settings > ATA Radio: the backend URL is pre-filled with the production backend (change it only if the backend moves), then Save.
3. Click "Test connection". It must report "Connected" and "CORS OK".
4. Add the [dominion_radio] shortcode to the Radio page (Elementor: Shortcode widget, inside a Full Width container).

The backend must list this website's exact origin (for example https://toluwalogoagboola.org) in its CORS settings.

== Security ==

The backend admin API key is used for server-side admin actions such as syncing sermons and saving playback/season settings. It is never sent to visitors. Prefer defining DOMINION_RADIO_ADMIN_KEY in wp-config.php.

== Changelog ==
= 3.0.0 =
* Added admin controls to stop/resume playback and create date-bounded seasonal sermon playlists with searchable sermon selection.
* Shows saved season details in the existing player intro without changing the player layout.
* Detects new broadcast cycles for single-sermon playlists so the audio restarts correctly.
= 2.9.2 =
* Rearranged the artwork. The photo now sits on the hero (left) side, behind the heading, and fades away towards the player (on phones and tablets it fills the top and fades downwards). The logo moved out of the heading and is now a large faded watermark on the right, behind the player, that brightens and breathes while you are in the room.
* "Photo size" now sets how much of the room the photo covers (small, medium, large); "fill" keeps the old full-screen photo.
= 2.9.1 =
* The backdrop photo is no longer cropped and zoomed to fill the whole screen. By default it now shows the whole picture at a smaller size, centred, with soft faded edges and only a very gentle drift. New setting "Photo size" and shortcode attribute bg_size (small, medium, large, fill) — "fill" restores the previous full-screen look.
= 2.9.0 =
* Photo backdrop in the style of the DOMI Radio stage: a full-bleed photograph behind the room (default: the Golden Tribute portrait montage), with a golden colour grade, a slow drifting push, an occasional sweep of light, and a dark veil so the heading and player stay readable. The veil adapts to the layout (heavier behind the words on desktop, even on phones and tablets). The picture brightens when you join the room.
* The player card is now frosted glass over the photo (falls back to the solid card where blur is unsupported).
* Logo badge above the heading: the ATA logo in a gold-ringed medallion with a travelling light and broadcast rings that quicken while you are in the room. Hidden on very short screens so the whole room still fits.
* New settings: Background image, Photo focus, Logo. New shortcode attributes: bg, logo, bg_position. Filters: dominion_radio_default_bg, dominion_radio_default_logo.
* All decorative, hidden from screen readers, off for visitors who prefer reduced motion. Player behaviour is unchanged.
= 2.8.2 =
* Main heading changed to "Sincere Worship, Intense Prayer, God’s Word" (gold accent on "God’s Word"); phone sizing adjusted so the longer heading still fits the screen.
= 2.8.1 =
* Renamed the station from "Dominion Radio" to "ATA Radio" everywhere visitors and admins see it (heading label, player, off-air message, settings page, plugin list). Sites that saved the old default name pick up the new one automatically; a custom name is left alone. Internal names (shortcode [dominion_radio], folder, CSS) are unchanged so existing pages keep working.
= 2.8.0 =
* Portrait image removed from the Radio page. Same copy, same player, same behaviour.
* One-screen layout: the room fills the screen below the site header (admin bar and theme header are measured automatically) and the page itself no longer scrolls. Side by side on desktop and landscape phones, stacked and centred on tablets and phones, compacted for small screens so the whole player always fits.
* Livelier page (decorative only, hidden from screen readers, off for visitors who prefer reduced motion): drifting golden light, slow rays and broadcast waves behind the player, rising sparks, a live equaliser skyline, shimmering heading accent, a travelling light along the player edge and a gentle pulse on "Join the Room". Everything lifts when you join the room.
* New optional shortcode attribute fit="no" to turn the one-screen behaviour off.
* The unused bundled portrait files were removed from the package.
= 2.7.0 =
* Redesigned player room: layout now adapts to the width of the column the shortcode sits in (container queries), so it no longer breaks inside narrow Elementor columns.
* New primary action: "Join the Room" / "Leave Room" (replaces Listen Live / Pause Broadcast), with an animated equaliser while you are in the room.
* Cleaner stacked player card: now playing, seek, join/leave and mute, up next.
= 2.6.3 =
* The player now defaults to the production backend (https://minster-livestream-monitor.onrender.com) when no backend URL is saved, so it plays immediately after activation. Settings, the backend attribute on the shortcode, or the dominion_radio_default_backend filter still override it.

= 2.6.2 =
* Radio page redesigned as a native ministry inner page using measured Sermons/About tokens (dark hero section, Playfair Display headings with gold italic accent, Inter body, pill actions).
* Studio layout: player first with portrait as supporting 4:5 framed image; player remains visible without scrolling.
* Preserves all v2.4.0 functionality: automatic Radio page creation, native range seek, station/local status separation, shared sync.
= 2.3.0 =
* The Live Console: transparent page shell with an immersive dark player panel as the first element; portrait secondary below.
* Native <input type="range"> seek control with keyboard/ARIA announcements and visible focus; station (ON AIR) status kept separate from local player status.
* Player panel is fluid (up to 880px) and fully responsive; restrained gold accents, ministry palette.
= 2.2.0 =
* Premium Editorial Broadcast redesign: combines Concept B's immersive live-radio player with the editorial design language of the About page (toluwalogoagboola.org).
* New portrait-led hero with Oswald headline, eyebrow identity label, ON AIR badge and gold-rule separator.
* Refined broadcast console: prominent play button, current track/performer, seek bar, time, mute, Back to Live and compact Up Next.
* Responsive compositions for 1440px desktop, 768px tablet and 390px/375px mobile.
* All playback logic, backend integration and WordPress hooks unchanged.
= 2.1.0 =
* Integrated the actual Apostle Toluwalogo Agboola portrait (WebP with JPEG fallback, natural 2:3 proportions, no external image dependency).
* Matched the Radio page design to the toluwalogoagboola.org design system (dark #0a0908 background, cream #f5efe0 text, gold #f0d17e/#d4af37/#a97e2f accents, Playfair Display headings, Inter body).
* Removed the placeholder portrait and all preview harnesses/mock assets from the package.
= 2.0.0 =
* New immersive broadcast design, backend-accurate player, accessible seek slider, Up Next, Back to live, settings page with connection test.
