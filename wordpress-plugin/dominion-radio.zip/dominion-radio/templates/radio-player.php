<?php
/**
 * ATA Radio player markup — v2.9.0 live room (single-screen, faded photo on the hero side + faded logo behind the player).
 *
 * Left: eyebrow, heading, description, ON AIR status.
 * Right: the player card, framed by animated broadcast waves.
 * Behind everything: a purely decorative, aria-hidden atmosphere layer
 * (full-bleed photo backdrop, drifting light, rising sparks, a live equaliser skyline).
 * The logo: a large faded watermark on the right, behind the player (decorative, aria-hidden).
 * Desktop: side by side. Tablet/mobile: stacked and centred.
 * The whole room fits the screen (see data-fit) so the page does not scroll.
 *
 * Variables supplied by Dominion_Radio_Shortcode::render():
 *   $instance_id, $backend, $atts (name, tagline, offline_message, fit), $heading,
 *   $can_manage. $atts also carries bg, logo and bg_position (already validated).
 *
 * Track title / performer / duration / position / Up Next come from the
 * backend via JS — never hardcoded. All data-dr hooks retained.
 *
 * @package DominionRadio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$dr_initial_state = '' === $backend ? 'config' : 'loading';

// Ministry editorial copy. $atts['tagline'] still honoured when customised;
// the legacy default is upgraded to the new description.
$dr_lead = isset( $atts['tagline'] ) ? (string) $atts['tagline'] : '';
if ( '' === $dr_lead || 'Worship, the Word and prayer, wherever you are.' === $dr_lead ) {
	$dr_lead = __( 'A continuous stream of sermons, worship and messages to strengthen your walk with God.', 'dominion-radio' );
}
$dr_eyebrow = ( 0 === strcasecmp( (string) $atts['name'], 'ATA Radio' ) || 0 === strcasecmp( (string) $atts['name'], 'Dominion Radio' ) )
	? __( 'ATA RADIO · LIVE MINISTRY BROADCAST', 'dominion-radio' )
	: strtoupper( (string) $atts['name'] ) . ' · ' . __( 'LIVE MINISTRY BROADCAST', 'dominion-radio' );

// Decorative-only values (deterministic, so the markup is cache friendly).
$dr_fit    = ( isset( $atts['fit'] ) && in_array( strtolower( (string) $atts['fit'] ), array( 'no', 'false', '0', 'off' ), true ) ) ? '0' : '1';
$dr_bg     = isset( $atts['bg'] ) ? (string) $atts['bg'] : '';
$dr_logo   = isset( $atts['logo'] ) ? (string) $atts['logo'] : '';
$dr_bgpos  = isset( $atts['bg_position'] ) ? (string) $atts['bg_position'] : 'center 22%';
$dr_bgsize = isset( $atts['bg_size'] ) ? (string) $atts['bg_size'] : 'medium';
// Photo panel width (share of the room, side-by-side layout). The photo sits on the hero (left) side.
$dr_bgw    = array( 'small' => '42%', 'medium' => '56%', 'large' => '72%', 'fill' => '100%' );
$dr_bgw    = isset( $dr_bgw[ $dr_bgsize ] ) ? $dr_bgw[ $dr_bgsize ] : '56%';
$dr_bars   = array();
for ( $i = 0; $i < 56; $i++ ) {
	$h = 0.28 + 0.72 * abs( sin( $i * 0.61 ) * cos( $i * 0.23 + 1.1 ) );
	$dr_bars[] = sprintf( '--i:%d;--h:%.2f', $i, $h );
}
$dr_sparks = array();
for ( $i = 0; $i < 18; $i++ ) {
	$x  = ( ( $i * 37 ) % 96 ) + 2;
	$sz = 2 + ( $i % 4 );
	$t  = 9 + ( ( $i * 5 ) % 9 );
	$d  = -1 * ( ( $i * 7 ) % $t );
	$dx = ( ( $i % 2 ) ? 1 : -1 ) * ( 10 + ( ( $i * 11 ) % 40 ) );
	$dr_sparks[] = sprintf( 'left:%d%%;--s:%dpx;--t:%ds;--d:%ds;--dx:%dpx', $x, $sz, $t, $d, $dx );
}
?>
<div class="dr-radio" id="<?php echo esc_attr( $instance_id ); ?>" data-state="<?php echo esc_attr( $dr_initial_state ); ?>" data-backend-url="<?php echo esc_url( $backend ); ?>" data-name="<?php echo esc_attr( $atts['name'] ); ?>" data-offline-message="<?php echo esc_attr( $atts['offline_message'] ); ?>" data-fit="<?php echo esc_attr( $dr_fit ); ?>" data-bg="<?php echo '' !== $dr_bg ? '1' : '0'; ?>" data-bgsize="<?php echo esc_attr( $dr_bgsize ); ?>" data-logo="<?php echo '' !== $dr_logo ? '1' : '0'; ?>"<?php if ( '' !== $dr_bg ) : ?> style="--dr-bg-pos:<?php echo esc_attr( $dr_bgpos ); ?>;--dr-bg-w:<?php echo esc_attr( $dr_bgw ); ?>"<?php endif; ?>>

	<!-- Decorative atmosphere: no content, hidden from assistive tech. -->
	<div class="dr-atmos" aria-hidden="true">
		<?php if ( '' !== $dr_bg || '' !== $dr_logo ) : ?>
			<span class="dr-backdrop">
				<?php if ( '' !== $dr_bg ) : ?>
					<img class="dr-backdrop__img" src="<?php echo esc_url( $dr_bg ); ?>" alt="" decoding="async" fetchpriority="high" draggable="false" />
					<span class="dr-backdrop__tint"></span>
					<span class="dr-backdrop__dim"></span>
					<span class="dr-backdrop__scrim"></span>
				<?php endif; ?>
				<?php if ( '' !== $dr_logo ) : ?>
					<img class="dr-backdrop__logo" src="<?php echo esc_url( $dr_logo ); ?>" alt="" decoding="async" draggable="false" />
				<?php endif; ?>
			</span>
		<?php endif; ?>
		<span class="dr-atmos__glow dr-atmos__glow--a"></span>
		<span class="dr-atmos__glow dr-atmos__glow--b"></span>
		<span class="dr-atmos__glow dr-atmos__glow--c"></span>
		<span class="dr-atmos__rays"></span>
		<span class="dr-atmos__waves"><i></i><i></i><i></i><i></i></span>
		<span class="dr-atmos__sparks">
			<?php foreach ( $dr_sparks as $dr_spark ) : ?>
				<i style="<?php echo esc_attr( $dr_spark ); ?>"></i>
			<?php endforeach; ?>
		</span>
		<span class="dr-atmos__bars">
			<?php foreach ( $dr_bars as $dr_bar ) : ?>
				<i style="<?php echo esc_attr( $dr_bar ); ?>"></i>
			<?php endforeach; ?>
		</span>
	</div>

	<div class="dr-hero">

		<!-- Left column: identity and status. -->
		<div class="dr-hero__copy">
			<p class="dr-eyebrow"><?php echo esc_html( $dr_eyebrow ); ?></p>
			<h1 class="dr-title"><?php echo esc_html__( 'Sincere Worship, Intense Prayer, ', 'dominion-radio' ); ?><em><?php echo esc_html__( 'God’s Word', 'dominion-radio' ); ?></em></h1>
			<p class="dr-lead"><?php echo esc_html( $dr_lead ); ?></p>

			<span class="dr-onair" data-dr="onair">
				<span class="dr-onair__dot" aria-hidden="true"></span>
				<span class="dr-onair__text" data-dr="status"><?php echo 'config' === $dr_initial_state ? esc_html__( 'Not set up', 'dominion-radio' ) : esc_html__( 'Connecting', 'dominion-radio' ); ?></span>
			</span>
		</div>

		<!-- Right column: the player (the listening experience). -->
		<div class="dr-hero__stage">
			<section class="dr-player" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: station name */ __( '%s player', 'dominion-radio' ), $atts['name'] ) ); ?>">

				<div class="dr-notice" data-dr="notice" hidden>
					<p class="dr-notice__title" data-dr="notice-title"></p>
					<p class="dr-notice__sub" data-dr="notice-sub"></p>
					<button type="button" class="dr-btn dr-btn--retry" data-dr="retry"><?php esc_html_e( 'Try Again', 'dominion-radio' ); ?></button>
				</div>

				<div class="dr-player__card" data-dr="card">

					<div class="dr-player__head">
						<span class="dr-player__label">
							<span class="dr-eq" aria-hidden="true"><i></i><i></i><i></i><i></i></span>
							<?php esc_html_e( 'Now playing', 'dominion-radio' ); ?>
						</span>
						<button type="button" class="dr-btn dr-btn--live" data-dr="golive" hidden><?php esc_html_e( 'Back to live', 'dominion-radio' ); ?></button>
					</div>

					<div class="dr-player__track">
						<p class="dr-player__track-title" data-dr="title"><?php esc_html_e( 'Connecting…', 'dominion-radio' ); ?></p>
						<p class="dr-player__performer" data-dr="performer"></p>
					</div>

					<div class="dr-player__progress">
						<input class="dr-seek" data-dr="seek" type="range" min="0" max="0" step="0.1" value="0" aria-label="<?php esc_attr_e( 'Seek within this track', 'dominion-radio' ); ?>" aria-valuemin="0" aria-valuemax="0" aria-valuenow="0" aria-valuetext="" aria-disabled="true" disabled />
						<p class="dr-player__time" aria-hidden="true"><span data-dr="elapsed">0:00</span><span class="dr-player__time-sep"> / </span><span data-dr="total">0:00</span></p>
					</div>

					<div class="dr-player__controls">
						<button type="button" class="dr-btn dr-btn--play" data-dr="play" aria-label="<?php esc_attr_e( 'Join the Room', 'dominion-radio' ); ?>" disabled>
							<svg class="dr-icon dr-icon--play" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" d="M4.5 15v-3a7.5 7.5 0 0 1 15 0v3"/><rect x="3" y="14" width="4.2" height="6.5" rx="1.6" fill="currentColor"/><rect x="16.8" y="14" width="4.2" height="6.5" rx="1.6" fill="currentColor"/></svg>
							<svg class="dr-icon dr-icon--pause" viewBox="0 0 24 24" aria-hidden="true" focusable="false" hidden><path fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" d="M9 4.5H6.5A1.5 1.5 0 0 0 5 6v12a1.5 1.5 0 0 0 1.5 1.5H9M15 8l4 4-4 4M19 12H9.5"/></svg>
							<span class="dr-spinner" aria-hidden="true"></span>
							<span class="dr-play__label" data-dr="play-label"><?php esc_html_e( 'Join the Room', 'dominion-radio' ); ?></span>
						</button>
						<button type="button" class="dr-btn dr-btn--mute" data-dr="mute" aria-label="<?php esc_attr_e( 'Mute', 'dominion-radio' ); ?>" aria-pressed="false">
							<svg class="dr-icon dr-icon--vol" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M4 9.5v5h3.4L12 18.5v-13L7.4 9.5z"/><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" d="M15.6 9.2a4 4 0 0 1 0 5.6M18.2 6.6a7.6 7.6 0 0 1 0 10.8"/></svg>
							<svg class="dr-icon dr-icon--muted" viewBox="0 0 24 24" aria-hidden="true" focusable="false" hidden><path fill="currentColor" d="M4 9.5v5h3.4L12 18.5v-13L7.4 9.5z"/><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" d="M16 9.6l4.8 4.8M20.8 9.6L16 14.4"/></svg>
						</button>
					</div>

					<div class="dr-player__next" data-dr="next" hidden>
						<span class="dr-player__next-label"><?php esc_html_e( 'Up next', 'dominion-radio' ); ?></span>
						<span class="dr-player__next-text">
							<span class="dr-player__next-title" data-dr="next-title"></span>
							<span class="dr-player__next-performer" data-dr="next-performer"></span>
						</span>
					</div>
				</div>

				<p class="dr-sr" role="status" aria-live="polite" data-dr="announce"></p>
				<noscript><p class="dr-noscript"><?php esc_html_e( 'Please enable JavaScript to listen to ATA Radio.', 'dominion-radio' ); ?></p></noscript>
				<?php if ( 'config' === $dr_initial_state && $can_manage ) : ?>
					<p class="dr-admin-hint"><?php echo esc_html__( 'Administrator note: set the backend URL under Settings → ATA Radio. Visitors will see a "not available" message until then.', 'dominion-radio' ); ?></p>
				<?php endif; ?>
				<audio class="dr-audio" data-dr="audio" preload="none"></audio>
			</section>
		</div>

	</div>
</div>
