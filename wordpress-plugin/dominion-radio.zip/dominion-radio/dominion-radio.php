<?php
/**
 * Plugin Name:       ATA Radio
 * Description:       Listen-live player for ATA Radio. Place it on any page with the [dominion_radio] shortcode. Connects to the ATA Radio backend (GET /radio/now and /radio/audio/{id}).
 * Version:           3.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            ATA Radio
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       dominion-radio
 *
 * @package DominionRadio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DOMINION_RADIO_VERSION', '3.0.0' );
define( 'DOMINION_RADIO_FILE', __FILE__ );
define( 'DOMINION_RADIO_DIR', plugin_dir_path( __FILE__ ) );
define( 'DOMINION_RADIO_URL', plugin_dir_url( __FILE__ ) );

// Backend used when none is saved in Settings > ATA Radio. Override with the
// 'dominion_radio_default_backend' filter, a shortcode backend="..." attribute, or the Settings page.
define( 'DOMINION_RADIO_DEFAULT_BACKEND', 'https://minster-livestream-monitor.onrender.com' );

// Default artwork for the room (hosted on the ministry website). Override in Settings > ATA Radio,
// with the shortcode attributes bg="..." / logo="..." (use "none" to turn one off), or with the
// 'dominion_radio_default_bg' / 'dominion_radio_default_logo' filters.
define( 'DOMINION_RADIO_DEFAULT_BG', 'https://toluwalogoagboola.org/wp-content/uploads/2026/11/Golden-Tribute-Portrait-Montage.png' );
define( 'DOMINION_RADIO_DEFAULT_LOGO', 'https://toluwalogoagboola.org/wp-content/uploads/2026/08/cropped-ATA-logo.png' );

require_once DOMINION_RADIO_DIR . 'includes/class-settings.php';
require_once DOMINION_RADIO_DIR . 'includes/class-shortcode.php';
require_once DOMINION_RADIO_DIR . 'includes/class-radio-page.php';

Dominion_Radio_Settings::init();
Dominion_Radio_Shortcode::init();
Dominion_Radio_Page::init();
