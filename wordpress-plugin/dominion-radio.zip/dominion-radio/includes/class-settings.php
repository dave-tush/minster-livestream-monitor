<?php
/**
 * Settings page, backend URL validation and the administrator-only backend actions.
 *
 * The backend ADMIN_API_KEY (needed only for POST /radio/sync-now) is used exclusively on the
 * server, from this class. It is never printed into a page, script or data attribute.
 *
 * @package DominionRadio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Dominion_Radio_Settings {

	const OPTION = 'dominion_radio_options';
	const SLUG   = 'dominion-radio';

	/**
	 * Default option values.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'backend_url'     => '',
			'station_name'    => 'ATA Radio',
			'tagline'         => 'A continuous stream of sermons, worship and messages to strengthen your walk with God.',
			'offline_message' => 'ATA Radio is not on air right now.',
			'portrait_id'     => 0,
			'bg_url'          => (string) apply_filters( 'dominion_radio_default_bg', DOMINION_RADIO_DEFAULT_BG ),
			'logo_url'        => (string) apply_filters( 'dominion_radio_default_logo', DOMINION_RADIO_DEFAULT_LOGO ),
			'bg_position'     => 'center 22%',
			'bg_size'         => 'medium',
			'admin_api_key'   => '',
		);
	}

	/**
	 * Read one option (or all of them).
	 *
	 * @param string|null $key Option key.
	 * @return mixed
	 */
	public static function get( $key = null ) {
		$saved = get_option( self::OPTION, array() );
		$opts  = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		// Sites that saved the old default name keep working: show the new name unless a custom one was chosen.
		if ( 'Dominion Radio' === $opts['station_name'] ) {
			$opts['station_name'] = 'ATA Radio';
		}
		if ( 'Dominion Radio is not on air right now.' === $opts['offline_message'] ) {
			$opts['offline_message'] = 'ATA Radio is not on air right now.';
		}
		// Nothing saved yet: fall back to the bundled production backend so the player works out of the box.
		if ( '' === $opts['backend_url'] ) {
			$opts['backend_url'] = self::sanitize_backend_url( (string) apply_filters( 'dominion_radio_default_backend', DOMINION_RADIO_DEFAULT_BACKEND ) );
		}
		if ( null === $key ) {
			return $opts;
		}
		return isset( $opts[ $key ] ) ? $opts[ $key ] : '';
	}

	/**
	 * The backend ADMIN_API_KEY. A DOMINION_RADIO_ADMIN_KEY constant in wp-config.php wins over the saved option.
	 *
	 * @return string
	 */
	public static function admin_key() {
		if ( defined( 'DOMINION_RADIO_ADMIN_KEY' ) && is_string( DOMINION_RADIO_ADMIN_KEY ) && '' !== DOMINION_RADIO_ADMIN_KEY ) {
			return DOMINION_RADIO_ADMIN_KEY;
		}
		return (string) self::get( 'admin_api_key' );
	}

	/**
	 * Allowed focal points for the background photo (label by CSS object-position value).
	 *
	 * @return array
	 */
	public static function bg_positions() {
		return array(
			'center 22%'    => __( 'Upper centre (best for portraits and faces)', 'dominion-radio' ),
			'center center' => __( 'Centre', 'dominion-radio' ),
			'center top'    => __( 'Top', 'dominion-radio' ),
			'center bottom' => __( 'Bottom', 'dominion-radio' ),
			'left center'   => __( 'Left', 'dominion-radio' ),
			'right center'  => __( 'Right', 'dominion-radio' ),
		);
	}

	/**
	 * Allowed sizes for the background photo.
	 *
	 * @return array
	 */
	public static function bg_sizes() {
		return array(
			'small'  => __( 'Small (framed in the middle, soft edges)', 'dominion-radio' ),
			'medium' => __( 'Medium (default)', 'dominion-radio' ),
			'large'  => __( 'Large (whole picture, as big as the screen allows)', 'dominion-radio' ),
			'fill'   => __( 'Fill the screen (cropped)', 'dominion-radio' ),
		);
	}

	/**
	 * Validate a photo size (falls back to the default).
	 *
	 * @param string $size Raw value.
	 * @return string
	 */
	public static function sanitize_bg_size( $size ) {
		$size = strtolower( trim( (string) $size ) );
		return array_key_exists( $size, self::bg_sizes() ) ? $size : self::defaults()['bg_size'];
	}

	/**
	 * Validate an image address: https only, no credentials. Returns '' when unusable.
	 * "none" / "off" / "no" mean "no image" and also return ''.
	 *
	 * @param string $url Raw address.
	 * @return string
	 */
	public static function sanitize_image_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url || in_array( strtolower( $url ), array( 'none', 'off', 'no', 'false', '0' ), true ) ) {
			return '';
		}
		$clean = esc_url_raw( $url, array( 'https' ) );
		if ( '' === $clean ) {
			return '';
		}
		$parts = wp_parse_url( $clean );
		if ( empty( $parts['host'] ) || ! empty( $parts['user'] ) || ! empty( $parts['pass'] ) ) {
			return '';
		}
		return $clean;
	}

	/**
	 * Validate a focal point against the allowed list (falls back to the default).
	 *
	 * @param string $pos Raw value.
	 * @return string
	 */
	public static function sanitize_bg_position( $pos ) {
		$pos = strtolower( trim( preg_replace( '/\s+/', ' ', (string) $pos ) ) );
		return array_key_exists( $pos, self::bg_positions() ) ? $pos : self::defaults()['bg_position'];
	}

	/**
	 * Validate and normalise a backend base URL.
	 *
	 * Accepts https://host[:port][/base-path]. Plain http is accepted only for localhost
	 * (development), because a secure site cannot load audio from an insecure origin.
	 *
	 * @param string $url Raw URL.
	 * @return string Normalised URL without trailing slash, or '' if invalid.
	 */
	public static function sanitize_backend_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url || strlen( $url ) > 300 ) {
			return '';
		}
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return '';
		}
		$scheme = strtolower( $parts['scheme'] );
		$host   = strtolower( $parts['host'] );
		if ( isset( $parts['user'] ) || isset( $parts['pass'] ) || isset( $parts['query'] ) || isset( $parts['fragment'] ) ) {
			return '';
		}
		$is_local = in_array( $host, array( 'localhost', '127.0.0.1', '[::1]', '::1' ), true );
		if ( 'https' !== $scheme && ! ( 'http' === $scheme && $is_local ) ) {
			return '';
		}
		$clean = $scheme . '://' . $host;
		if ( ! empty( $parts['port'] ) ) {
			$clean .= ':' . (int) $parts['port'];
		}
		if ( ! empty( $parts['path'] ) ) {
			$clean .= '/' . trim( $parts['path'], '/' );
		}
		return esc_url_raw( rtrim( $clean, '/' ) );
	}

	/**
	 * Hook everything up.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_init', array( 'Dominion_Radio_Page', 'maybe_create_page' ) );
			add_action( 'admin_post_dominion_radio_test', array( __CLASS__, 'handle_test' ) );
			add_action( 'admin_post_dominion_radio_sync', array( __CLASS__, 'handle_sync' ) );
			add_action( 'admin_post_dominion_radio_save_season', array( __CLASS__, 'handle_save_season' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( DOMINION_RADIO_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * "Settings" link on the Plugins screen.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public static function action_links( $links ) {
		$url = admin_url( 'options-general.php?page=' . self::SLUG );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'dominion-radio' ) . '</a>' );
		return $links;
	}

	/**
	 * Settings > ATA Radio.
	 */
	public static function add_menu() {
		add_options_page(
			__( 'ATA Radio', 'dominion-radio' ),
			__( 'ATA Radio', 'dominion-radio' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Register the option (Settings API handles the nonce and capability check on save).
	 */
	public static function register() {
		register_setting(
			'dominion_radio',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);
	}

	/**
	 * Sanitise the whole options array.
	 *
	 * @param mixed $input Raw form input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$old   = self::get();
		$input = is_array( $input ) ? $input : array();
		$out   = $old;

		if ( isset( $input['backend_url'] ) ) {
			$raw = trim( wp_unslash( (string) $input['backend_url'] ) );
			if ( '' === $raw ) {
				$out['backend_url'] = '';
			} else {
				$clean = self::sanitize_backend_url( $raw );
				if ( '' === $clean ) {
					// add_settings_error() only exists inside wp-admin; this callback can also run via REST or WP-CLI.
					if ( function_exists( 'add_settings_error' ) ) {
						add_settings_error( self::OPTION, 'dr_url', __( 'The backend URL was not saved. Use a full https:// address such as https://your-radio.onrender.com (no query string, no credentials).', 'dominion-radio' ) );
					}
				} else {
					$out['backend_url'] = $clean;
				}
			}
		}
		if ( isset( $input['station_name'] ) ) {
			$name                = sanitize_text_field( wp_unslash( $input['station_name'] ) );
			$out['station_name'] = '' !== $name ? mb_substr( $name, 0, 60 ) : self::defaults()['station_name'];
		}
		if ( isset( $input['tagline'] ) ) {
			$out['tagline'] = mb_substr( sanitize_text_field( wp_unslash( $input['tagline'] ) ), 0, 160 );
		}
		if ( isset( $input['offline_message'] ) ) {
			$msg                    = sanitize_text_field( wp_unslash( $input['offline_message'] ) );
			$out['offline_message'] = '' !== $msg ? mb_substr( $msg, 0, 160 ) : self::defaults()['offline_message'];
		}
		if ( isset( $input['portrait_id'] ) ) {
			$id = absint( $input['portrait_id'] );
			// Only accept a real image attachment.
			$out['portrait_id'] = ( $id && wp_attachment_is_image( $id ) ) ? $id : 0;
		}
		// Artwork: a blank field turns that image off; an unusable address keeps the saved one.
		foreach ( array( 'bg_url' => __( 'Background image', 'dominion-radio' ), 'logo_url' => __( 'Logo', 'dominion-radio' ) ) as $key => $label ) {
			if ( ! isset( $input[ $key ] ) ) {
				continue;
			}
			$raw = trim( wp_unslash( (string) $input[ $key ] ) );
			if ( '' === $raw ) {
				$out[ $key ] = '';
				continue;
			}
			$clean = self::sanitize_image_url( $raw );
			if ( '' === $clean ) {
				if ( function_exists( 'add_settings_error' ) ) {
					/* translators: %s: field label */
					add_settings_error( self::OPTION, 'dr_' . $key, sprintf( __( '%s was not saved. Use a full https:// image address.', 'dominion-radio' ), $label ) );
				}
			} else {
				$out[ $key ] = $clean;
			}
		}
		if ( isset( $input['bg_position'] ) ) {
			$out['bg_position'] = self::sanitize_bg_position( wp_unslash( (string) $input['bg_position'] ) );
		}
		if ( isset( $input['bg_size'] ) ) {
			$out['bg_size'] = self::sanitize_bg_size( wp_unslash( (string) $input['bg_size'] ) );
		}
		// Admin key: blank input keeps the saved key; the "remove" box clears it.
		if ( ! empty( $input['remove_admin_api_key'] ) ) {
			$out['admin_api_key'] = '';
		} elseif ( isset( $input['admin_api_key'] ) && '' !== trim( (string) $input['admin_api_key'] ) ) {
			$key                  = preg_replace( '/[^\x21-\x7E]/', '', wp_unslash( (string) $input['admin_api_key'] ) );
			$out['admin_api_key'] = substr( (string) $key, 0, 200 );
		}
		unset( $out['remove_admin_api_key'] );
		return $out;
	}

	/**
	 * Server-side request to the backend.
	 *
	 * @param string $method  GET or POST.
	 * @param string $path    Path beginning with /.
	 * @param array  $headers Request headers.
	 * @param int    $timeout Seconds.
	 * @return array|WP_Error
	 */
		private static function backend_request( $method, $path, $headers = array(), $timeout = 15, $body = null ) {
		$base = self::get( 'backend_url' );
		if ( '' === $base ) {
			return new WP_Error( 'dr_no_backend', __( 'Save a backend URL first.', 'dominion-radio' ) );
		}
			$args = array(
				'method'      => $method,
				'timeout'     => $timeout,
				'redirection' => 0,
				'headers'     => $headers,
			);
			if ( null !== $body ) {
				$args['headers']['Content-Type'] = 'application/json';
				$args['body'] = wp_json_encode( $body );
			}
			return wp_safe_remote_request( $base . $path, $args );
		}

	/**
	 * Remember a result message for the next settings page load.
	 *
	 * @param string $type    success|warning|error.
	 * @param string $message Plain text.
	 */
	private static function flash( $type, $message ) {
		set_transient( 'dominion_radio_flash_' . get_current_user_id(), array( $type, $message ), 120 );
	}

	/**
	 * Common guard for the two admin-post actions.
	 *
	 * @param string $action Nonce action.
	 */
	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'dominion-radio' ), 403 );
		}
		check_admin_referer( $action );
	}

	/**
	 * Redirect back to the settings page.
	 */
	private static function back() {
		wp_safe_redirect( admin_url( 'options-general.php?page=' . self::SLUG ) );
		exit;
	}

	/**
	 * "Test connection": GET /radio/now and check the CORS header for this site's origin.
	 */
	public static function handle_test() {
		self::guard( 'dominion_radio_test' );

		$home   = wp_parse_url( home_url() );
		$origin = $home['scheme'] . '://' . $home['host'] . ( ! empty( $home['port'] ) ? ':' . $home['port'] : '' );
		$res    = self::backend_request( 'GET', '/radio/now', array( 'Origin' => $origin, 'Accept' => 'application/json' ) );

		if ( is_wp_error( $res ) ) {
			self::flash( 'error', sprintf( /* translators: %s: error */ __( 'Could not reach the backend: %s', 'dominion-radio' ), $res->get_error_message() ) );
			self::back();
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( 503 === $code ) {
			self::flash( 'warning', __( 'The backend is reachable but reports the station has no audio yet (HTTP 503). Run a sync, or wait for the first Telegram sync.', 'dominion-radio' ) );
			self::back();
		}
		if ( 200 !== $code || ! is_array( $data ) || empty( $data['track']['title'] ) ) {
			self::flash( 'error', sprintf( /* translators: %d: HTTP status */ __( 'Unexpected response from /radio/now (HTTP %d).', 'dominion-radio' ), $code ) );
			self::back();
		}
		$acao = wp_remote_retrieve_header( $res, 'access-control-allow-origin' );
		$cors = ( $acao === $origin || '*' === $acao )
			? sprintf( /* translators: %s: origin */ __( 'CORS OK for %s.', 'dominion-radio' ), $origin )
			: sprintf( /* translators: %s: origin */ __( 'WARNING: the backend does not allow this site (%s) in its CORS settings, so browsers will block the player.', 'dominion-radio' ), $origin );
		$msg  = sprintf(
			/* translators: 1: track title, 2: tracks in rotation */
			__( 'Connected. On air: "%1$s" (%2$d tracks in rotation). ', 'dominion-radio' ),
			sanitize_text_field( $data['track']['title'] ),
			isset( $data['tracks_in_rotation'] ) ? (int) $data['tracks_in_rotation'] : 0
		) . $cors;
		self::flash( ( $acao === $origin || '*' === $acao ) ? 'success' : 'warning', $msg );
		self::back();
	}

	/**
	 * "Sync now": POST /radio/sync-now with the server-held admin key.
	 */
	public static function handle_sync() {
		self::guard( 'dominion_radio_sync' );

		$key = self::admin_key();
		if ( '' === $key ) {
			self::flash( 'error', __( 'No admin API key is saved, so sync cannot run.', 'dominion-radio' ) );
			self::back();
		}
		$res = self::backend_request( 'POST', '/radio/sync-now', array( 'X-API-Key' => $key, 'Accept' => 'application/json' ), 60 );
		if ( is_wp_error( $res ) ) {
			self::flash( 'error', sprintf( /* translators: %s: error */ __( 'Sync request failed: %s', 'dominion-radio' ), $res->get_error_message() ) );
			self::back();
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( 200 === $code && is_array( $data ) ) {
			self::flash(
				'success',
				sprintf(
					/* translators: 1: tracks added, 2: total */
					__( 'Sync complete. %1$d new track(s) added; %2$d in rotation.', 'dominion-radio' ),
					isset( $data['added'] ) ? (int) $data['added'] : 0,
					isset( $data['tracks_in_rotation'] ) ? (int) $data['tracks_in_rotation'] : 0
				)
			);
		} elseif ( 401 === $code ) {
			self::flash( 'error', __( 'The backend rejected the admin API key (HTTP 401).', 'dominion-radio' ) );
		} elseif ( 503 === $code ) {
			self::flash( 'error', __( 'The backend has no ADMIN_API_KEY configured, so sync is disabled there (HTTP 503).', 'dominion-radio' ) );
		} else {
			self::flash( 'error', sprintf( /* translators: %d: HTTP status */ __( 'Sync failed (HTTP %d). See the backend logs.', 'dominion-radio' ), $code ) );
		}
		self::back();
	}

	/** Save the admin-controlled radio mode and date-bounded season. */
	public static function handle_save_season() {
		self::guard( 'dominion_radio_save_season' );
		$key = self::admin_key();
		if ( '' === $key ) {
			self::flash( 'error', __( 'Save the backend admin API key before changing radio settings.', 'dominion-radio' ) );
			self::back();
		}
		$ids = isset( $_POST['season_track_ids'] ) && is_array( $_POST['season_track_ids'] )
			? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['season_track_ids'] ) ) ) ) ) : array();
		$payload = array(
			'enabled'     => ! empty( $_POST['radio_enabled'] ),
			'season_name' => isset( $_POST['season_name'] ) ? sanitize_text_field( wp_unslash( $_POST['season_name'] ) ) : '',
			'emphasis'    => isset( $_POST['emphasis'] ) ? sanitize_text_field( wp_unslash( $_POST['emphasis'] ) ) : '',
			'starts_on'   => isset( $_POST['starts_on'] ) ? sanitize_text_field( wp_unslash( $_POST['starts_on'] ) ) : '',
			'ends_on'     => isset( $_POST['ends_on'] ) ? sanitize_text_field( wp_unslash( $_POST['ends_on'] ) ) : '',
			'track_ids'   => $ids,
		);
		$res = self::backend_request( 'POST', '/radio/admin/config', array( 'X-API-Key' => $key, 'Accept' => 'application/json' ), 60, $payload );
		if ( is_wp_error( $res ) ) {
			self::flash( 'error', sprintf( __( 'Could not save radio settings: %s', 'dominion-radio' ), $res->get_error_message() ) );
			self::back();
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( 200 === $code ) {
			self::flash( 'success', __( 'Radio settings saved. The seasonal selection will be used during its date range.', 'dominion-radio' ) );
		} else {
			$data = json_decode( wp_remote_retrieve_body( $res ), true );
			$message = is_array( $data ) && ! empty( $data['detail'] ) ? sanitize_text_field( $data['detail'] ) : sprintf( __( 'Backend rejected the settings (HTTP %d).', 'dominion-radio' ), $code );
			self::flash( 'error', $message );
		}
		self::back();
	}

	/**
	 * Render the settings page.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o        = self::get();
		$name     = self::OPTION;
		$img_url  = $o['portrait_id'] ? wp_get_attachment_image_url( (int) $o['portrait_id'], 'medium' ) : '';
		$has_key  = '' !== self::admin_key();
		$const    = defined( 'DOMINION_RADIO_ADMIN_KEY' ) && '' !== DOMINION_RADIO_ADMIN_KEY;
		$flash_k  = 'dominion_radio_flash_' . get_current_user_id();
		$flash    = get_transient( $flash_k );
		if ( $flash ) {
			delete_transient( $flash_k );
		}
		wp_enqueue_media();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'ATA Radio', 'dominion-radio' ); ?></h1>
			<p><?php esc_html_e( 'Place the player on any page with the shortcode:', 'dominion-radio' ); ?> <code>[dominion_radio]</code></p>

			<?php if ( is_array( $flash ) ) : ?>
				<div class="notice notice-<?php echo esc_attr( in_array( $flash[0], array( 'success', 'warning', 'error' ), true ) ? $flash[0] : 'info' ); ?> is-dismissible"><p><?php echo esc_html( $flash[1] ); ?></p></div>
			<?php endif; ?>
			<?php settings_errors( self::OPTION ); ?>

			<form method="post" action="options.php">
				<?php settings_fields( 'dominion_radio' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="dr-backend"><?php esc_html_e( 'Backend URL', 'dominion-radio' ); ?></label></th>
						<td>
							<input id="dr-backend" type="url" class="regular-text code" name="<?php echo esc_attr( $name ); ?>[backend_url]" value="<?php echo esc_attr( $o['backend_url'] ); ?>" placeholder="https://your-radio.onrender.com" />
							<p class="description"><?php esc_html_e( 'The address of the ATA Radio backend, without a trailing slash. It must be https:// and must allow this website in its CORS settings.', 'dominion-radio' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="dr-name"><?php esc_html_e( 'Station name', 'dominion-radio' ); ?></label></th>
						<td><input id="dr-name" type="text" class="regular-text" maxlength="60" name="<?php echo esc_attr( $name ); ?>[station_name]" value="<?php echo esc_attr( $o['station_name'] ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="dr-tagline"><?php esc_html_e( 'Tagline', 'dominion-radio' ); ?></label></th>
						<td><input id="dr-tagline" type="text" class="large-text" maxlength="160" name="<?php echo esc_attr( $name ); ?>[tagline]" value="<?php echo esc_attr( $o['tagline'] ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="dr-offline"><?php esc_html_e( 'Off-air message', 'dominion-radio' ); ?></label></th>
						<td><input id="dr-offline" type="text" class="large-text" maxlength="160" name="<?php echo esc_attr( $name ); ?>[offline_message]" value="<?php echo esc_attr( $o['offline_message'] ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="dr-bg"><?php esc_html_e( 'Background image', 'dominion-radio' ); ?></label></th>
						<td>
							<input id="dr-bg" type="url" class="large-text code" name="<?php echo esc_attr( $name ); ?>[bg_url]" value="<?php echo esc_attr( $o['bg_url'] ); ?>" placeholder="https://…/photo.png" />
							<p class="description"><?php esc_html_e( 'Full-screen photo behind the player (https:// address). Leave blank for no photo. A wide, high-resolution image works best; the page darkens it so the text stays readable.', 'dominion-radio' ); ?></p>
							<?php if ( '' !== $o['bg_url'] ) : ?><div style="margin-top:8px"><img src="<?php echo esc_url( $o['bg_url'] ); ?>" alt="" style="max-width:220px;height:auto;display:block;border:1px solid #ccd0d4" /></div><?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="dr-bgsize"><?php esc_html_e( 'Photo size', 'dominion-radio' ); ?></label></th>
						<td>
							<select id="dr-bgsize" name="<?php echo esc_attr( $name ); ?>[bg_size]">
								<?php foreach ( self::bg_sizes() as $size => $size_label ) : ?>
									<option value="<?php echo esc_attr( $size ); ?>" <?php selected( $o['bg_size'], $size ); ?>><?php echo esc_html( $size_label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'How large the photo appears behind the player.', 'dominion-radio' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="dr-bgpos"><?php esc_html_e( 'Photo focus', 'dominion-radio' ); ?></label></th>
						<td>
							<select id="dr-bgpos" name="<?php echo esc_attr( $name ); ?>[bg_position]">
								<?php foreach ( self::bg_positions() as $pos => $pos_label ) : ?>
									<option value="<?php echo esc_attr( $pos ); ?>" <?php selected( $o['bg_position'], $pos ); ?>><?php echo esc_html( $pos_label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Which part of the photo stays in view when the screen shape crops it.', 'dominion-radio' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="dr-logo"><?php esc_html_e( 'Logo', 'dominion-radio' ); ?></label></th>
						<td>
							<input id="dr-logo" type="url" class="large-text code" name="<?php echo esc_attr( $name ); ?>[logo_url]" value="<?php echo esc_attr( $o['logo_url'] ); ?>" placeholder="https://…/logo.png" />
							<p class="description"><?php esc_html_e( 'Shown as a glowing badge above the heading. A square image works best (it is cropped to a circle). Leave blank for no logo.', 'dominion-radio' ); ?></p>
							<?php if ( '' !== $o['logo_url'] ) : ?><div style="margin-top:8px"><img src="<?php echo esc_url( $o['logo_url'] ); ?>" alt="" style="width:64px;height:64px;object-fit:cover;border-radius:50%;display:block;border:1px solid #ccd0d4" /></div><?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Portrait', 'dominion-radio' ); ?></th>
						<td>
							<input type="hidden" id="dr-portrait-id" name="<?php echo esc_attr( $name ); ?>[portrait_id]" value="<?php echo esc_attr( (int) $o['portrait_id'] ); ?>" />
							<div id="dr-portrait-preview" style="margin-bottom:8px"><?php if ( $img_url ) : ?><img src="<?php echo esc_url( $img_url ); ?>" alt="" style="max-width:150px;height:auto;display:block" /><?php endif; ?></div>
							<button type="button" class="button" id="dr-portrait-pick"><?php esc_html_e( 'Choose from Media Library', 'dominion-radio' ); ?></button>
							<button type="button" class="button-link" id="dr-portrait-clear"><?php esc_html_e( 'Remove', 'dominion-radio' ); ?></button>
							<p class="description"><?php esc_html_e( 'The Radio page no longer displays a portrait (v2.8.0), so this setting currently has no visible effect. It is kept so a portrait can be brought back later without losing your choice.', 'dominion-radio' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="dr-key"><?php esc_html_e( 'Backend admin API key', 'dominion-radio' ); ?></label></th>
						<td>
							<?php if ( $const ) : ?>
								<p><em><?php esc_html_e( 'Provided by the DOMINION_RADIO_ADMIN_KEY constant in wp-config.php.', 'dominion-radio' ); ?></em></p>
							<?php else : ?>
								<input id="dr-key" type="password" class="regular-text code" autocomplete="new-password" name="<?php echo esc_attr( $name ); ?>[admin_api_key]" value="" placeholder="<?php echo $has_key ? esc_attr__( '(saved — leave blank to keep)', 'dominion-radio' ) : ''; ?>" />
								<?php if ( $has_key ) : ?>
									<label style="margin-left:8px"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[remove_admin_api_key]" value="1" /> <?php esc_html_e( 'Remove saved key', 'dominion-radio' ); ?></label>
								<?php endif; ?>
							<?php endif; ?>
				<p class="description"><?php esc_html_e( 'Used by server-side admin actions such as syncing sermons and saving playback/season settings. It is never sent to visitors\' browsers. For better security, define DOMINION_RADIO_ADMIN_KEY in wp-config.php instead.', 'dominion-radio' ); ?></p>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>

			<h2><?php esc_html_e( 'Backend tools', 'dominion-radio' ); ?></h2>
			<div style="display:flex;gap:12px;flex-wrap:wrap">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="dominion_radio_test" />
					<?php wp_nonce_field( 'dominion_radio_test' ); ?>
					<?php submit_button( __( 'Test connection', 'dominion-radio' ), 'secondary', 'submit', false, array( 'disabled' => '' === $o['backend_url'] ? 'disabled' : null ) ); ?>
				</form>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="dominion_radio_sync" />
					<?php wp_nonce_field( 'dominion_radio_sync' ); ?>
					<?php submit_button( __( 'Sync new uploads now', 'dominion-radio' ), 'secondary', 'submit', false, array( 'disabled' => ( '' === $o['backend_url'] || ! $has_key ) ? 'disabled' : null ) ); ?>
				</form>
			</div>
		<p class="description"><?php esc_html_e( '"Test connection" calls /radio/now and checks the CORS setting for this site. "Sync" asks the backend to pull new audio from Telegram immediately (needs the admin key).', 'dominion-radio' ); ?></p>

		<h2><?php esc_html_e( 'Radio season and playback', 'dominion-radio' ); ?></h2>
		<?php
		$radio_config = null;
		$sermons      = array();
		if ( $has_key && '' !== $o['backend_url'] ) {
			$cfg_res = self::backend_request( 'GET', '/radio/admin/config', array( 'X-API-Key' => self::admin_key(), 'Accept' => 'application/json' ) );
			if ( ! is_wp_error( $cfg_res ) && 200 === (int) wp_remote_retrieve_response_code( $cfg_res ) ) {
				$decoded = json_decode( wp_remote_retrieve_body( $cfg_res ), true );
				$radio_config = is_array( $decoded ) ? $decoded : null;
			}
			$offset = 0;
			$catalog_total = 0;
			do {
				$list_res = self::backend_request( 'GET', '/radio/catalog?limit=500&offset=' . $offset, array( 'Accept' => 'application/json' ), 30 );
				if ( is_wp_error( $list_res ) || 200 !== (int) wp_remote_retrieve_response_code( $list_res ) ) {
					break;
				}
				$list = json_decode( wp_remote_retrieve_body( $list_res ), true );
				if ( ! is_array( $list ) || empty( $list['tracks'] ) ) {
					break;
				}
				$sermons = array_merge( $sermons, $list['tracks'] );
				$catalog_total = isset( $list['total'] ) ? (int) $list['total'] : count( $sermons );
				$offset += count( $list['tracks'] );
			} while ( $offset < $catalog_total );
		}
		$season_ids = $radio_config && isset( $radio_config['season_track_ids'] ) ? array_map( 'intval', $radio_config['season_track_ids'] ) : array();
		?>
		<?php if ( ! $has_key ) : ?>
			<p class="description"><?php esc_html_e( 'Configure the backend admin API key above to manage playback and seasons.', 'dominion-radio' ); ?></p>
		<?php elseif ( ! $radio_config ) : ?>
			<div class="notice notice-warning inline"><p><?php esc_html_e( 'Could not load radio settings. Confirm that the backend is updated, running, and has ADMIN_API_KEY configured.', 'dominion-radio' ); ?></p></div>
		<?php else : ?>
			<p><strong><?php esc_html_e( 'Current status:', 'dominion-radio' ); ?></strong>
				<?php echo ! empty( $radio_config['enabled'] ) ? esc_html__( 'Radio enabled', 'dominion-radio' ) : esc_html__( 'Stopped by administrator', 'dominion-radio' ); ?>
				<?php if ( ! empty( $radio_config['season_name'] ) ) : ?>
					&mdash; <?php echo esc_html( $radio_config['season_name'] ); ?>: <?php echo esc_html( $radio_config['emphasis'] ); ?>
					(<?php echo esc_html( $radio_config['starts_on'] ); ?> &ndash; <?php echo esc_html( $radio_config['ends_on'] ); ?>; <?php echo ! empty( $radio_config['season_active'] ) ? esc_html__( 'active', 'dominion-radio' ) : esc_html__( 'not active yet / expired', 'dominion-radio' ); ?>)
				<?php else : ?>
					&mdash; <?php esc_html_e( 'No season configured; all available sermons play.', 'dominion-radio' ); ?>
				<?php endif; ?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="dominion_radio_save_season" />
				<?php wp_nonce_field( 'dominion_radio_save_season' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><?php esc_html_e( 'Playback', 'dominion-radio' ); ?></th><td><label><input type="checkbox" name="radio_enabled" value="1" <?php checked( ! empty( $radio_config['enabled'] ) ); ?> /> <?php esc_html_e( 'Radio is enabled (uncheck to stop the stream)', 'dominion-radio' ); ?></label><p class="description"><?php esc_html_e( 'Saving this setting takes effect immediately. Re-enable it to resume.', 'dominion-radio' ); ?></p></td></tr>
					<tr><th scope="row"><label for="dr-season-name"><?php esc_html_e( 'Season name', 'dominion-radio' ); ?></label></th><td><input id="dr-season-name" class="regular-text" maxlength="120" name="season_name" value="<?php echo esc_attr( $radio_config['season_name'] ); ?>" placeholder="<?php esc_attr_e( 'Consecration', 'dominion-radio' ); ?>" /></td></tr>
					<tr><th scope="row"><label for="dr-emphasis"><?php esc_html_e( 'Weekly emphasis', 'dominion-radio' ); ?></label></th><td><input id="dr-emphasis" class="regular-text" maxlength="200" name="emphasis" value="<?php echo esc_attr( $radio_config['emphasis'] ); ?>" placeholder="<?php esc_attr_e( 'Consecration', 'dominion-radio' ); ?>" /></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Season dates', 'dominion-radio' ); ?></th><td><label><?php esc_html_e( 'From', 'dominion-radio' ); ?> <input type="date" name="starts_on" value="<?php echo esc_attr( $radio_config['starts_on'] ); ?>" /></label> &nbsp; <label><?php esc_html_e( 'To', 'dominion-radio' ); ?> <input type="date" name="ends_on" value="<?php echo esc_attr( $radio_config['ends_on'] ); ?>" /></label><p class="description"><?php esc_html_e( 'Dates are interpreted in UTC and include both the first and last day.', 'dominion-radio' ); ?></p></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Season sermons', 'dominion-radio' ); ?></th><td>
						<input type="search" class="regular-text" id="dr-sermon-search" placeholder="<?php esc_attr_e( 'Search sermon names', 'dominion-radio' ); ?>" aria-label="<?php esc_attr_e( 'Search sermon names', 'dominion-radio' ); ?>" />
						<p class="description"><?php echo esc_html( sprintf( __( '%d sermon names available. Select one or more; audio files are not downloaded by this list. While the season is active, only selected sermons will rotate.', 'dominion-radio' ), count( $sermons ) ) ); ?></p>
						<div id="dr-sermon-list" style="max-height:320px;overflow:auto;border:1px solid #c3c4c7;background:#fff;padding:8px;max-width:640px">
							<?php foreach ( $sermons as $sermon ) : ?>
								<label class="dr-sermon-item" data-search="<?php echo esc_attr( strtolower( $sermon['title'] . ' ' . $sermon['performer'] ) ); ?>" style="display:block;padding:3px 0"><input type="checkbox" name="season_track_ids[]" value="<?php echo esc_attr( (int) $sermon['id'] ); ?>" <?php checked( in_array( (int) $sermon['id'], $season_ids, true ) ); ?> /> <?php echo esc_html( $sermon['title'] ); ?><?php if ( ! empty( $sermon['performer'] ) ) : ?> <span class="description">— <?php echo esc_html( $sermon['performer'] ); ?></span><?php endif; ?></label>
							<?php endforeach; ?>
							<?php if ( ! $sermons ) : ?><p><?php esc_html_e( 'No available sermon names found. Run “Sync new uploads now” first.', 'dominion-radio' ); ?></p><?php endif; ?>
						</div>
					</td></tr>
				</table>
				<?php submit_button( __( 'Save playback and season settings', 'dominion-radio' ) ); ?>
			</form>
			<script>
			(function(){var q=document.getElementById('dr-sermon-search'),items=document.querySelectorAll('.dr-sermon-item');if(!q){return;}q.addEventListener('input',function(){var term=q.value.toLocaleLowerCase();items.forEach(function(item){item.hidden=item.getAttribute('data-search').indexOf(term)===-1;});});})();
			</script>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Radio page', 'dominion-radio' ); ?></h2>
			<?php
			$page_id = Dominion_Radio_Page::get_page_id();
			$has_page = Dominion_Radio_Page::has_page();
			$page_url = Dominion_Radio_Page::get_page_url();
			?>
			<?php if ( $has_page && $page_url ) : ?>
				<div class="notice notice-success is-dismissible">
					<p>
						<?php
						echo wp_kses_post(
							sprintf(
								__( 'The Radio page has been created and is available at: <a href="%1$s" target="_blank" rel="noopener">%1$s</a>', 'dominion-radio' ),
								esc_url( $page_url )
							)
						);
						?>
					</p>
				</div>
			<?php elseif ( $page_id && ! $has_page ) : ?>
				<div class="notice notice-warning is-dismissible">
					<p><?php esc_html_e( 'A Radio page was previously created but appears to have been deleted or its content changed.', 'dominion-radio' ); ?></p>
				</div>
			<?php else : ?>
				<div class="notice notice-info is-dismissible">
					<p><?php esc_html_e( 'No Radio page has been created yet. It will be created automatically when the plugin is activated, or you can create it manually below.', 'dominion-radio' ); ?></p>
				</div>
			<?php endif; ?>

			<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-top:12px">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="dominion_radio_recreate_page" />
					<?php wp_nonce_field( 'dominion_radio_recreate_page' ); ?>
					<?php submit_button( __( 'Create / Recreate Radio Page', 'dominion-radio' ), 'secondary', 'submit', false ); ?>
				</form>
				<?php if ( $has_page && $page_url ) : ?>
					<a href="<?php echo esc_url( $page_url ); ?>" target="_blank" rel="noopener" class="button button-primary" style="text-decoration:none"><?php esc_html_e( 'View Radio Page', 'dominion-radio' ); ?></a>
				<?php endif; ?>
			</div>
			<p class="description"><?php esc_html_e( 'The Radio page contains the [dominion_radio] shortcode. It is created automatically on plugin activation. If deleted, use the button above to recreate it.', 'dominion-radio' ); ?></p>

			<h2><?php esc_html_e( 'Shortcode options', 'dominion-radio' ); ?></h2>
			<p><code>[dominion_radio]</code> &mdash; <code>backend="https://…"</code> <code>name="…"</code> <code>tagline="…"</code> <code>heading="h1|h2"</code> (default h2) <code>bg="https://…"</code> <code>logo="https://…"</code> <code>bg_position="center 22%"</code> <code>bg_size="small|medium|large|fill"</code> (use <code>bg="none"</code> or <code>logo="none"</code> to hide one)</p>
		</div>
		<script>
		(function(){
			var pick=document.getElementById('dr-portrait-pick'),clear=document.getElementById('dr-portrait-clear'),
				idEl=document.getElementById('dr-portrait-id'),prev=document.getElementById('dr-portrait-preview'),frame;
			if(!pick||!window.wp||!wp.media){return;}
			pick.addEventListener('click',function(){
				if(!frame){frame=wp.media({title:'Choose portrait',library:{type:'image'},multiple:false,button:{text:'Use this image'}});
					frame.on('select',function(){var a=frame.state().get('selection').first().toJSON();
						idEl.value=a.id;var u=(a.sizes&&a.sizes.medium)?a.sizes.medium.url:a.url;
						prev.innerHTML='';var i=document.createElement('img');i.src=u;i.alt='';i.style.cssText='max-width:150px;height:auto;display:block';prev.appendChild(i);});}
				frame.open();});
			clear.addEventListener('click',function(){idEl.value='0';prev.innerHTML='';});
		})();
		</script>
		<?php
	}
}
